<?php

return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=12312',
            'username' => '',
            'password' => '',

        ],
    ],

    'params' => [

    ]
];
