<?php

$config = [
    'id' => 'education-api-console',
    'name' => 'CyberClinic API',
    'basePath' => dirname(__DIR__) . '/',
    'controllerNamespace' => 'app\commands',
    'components' => [

    ],
    'modules' => [

    ],

    'params' => [

    ],
];


return $config;
