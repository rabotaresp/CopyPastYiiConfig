<?php

return [
    'web' => [
        '' => 'prod',
        'afasdf.com' => 'prod',
        'basic.local' => 'dev',
        'afdasfdasd.test' => 'test',
    ],
    'console' => [
        'DESKTOP-85IQ5R9:/D:\wamp64\www\matthew.local' => 'dev',
        'homeSRV://var/www/matthew/matthew' => 'prod',
        'ip-32423' => 'prod',
        'A505PCPREPOD:/C:\OpenServer\domains\basic' => 'dev',
    ],
];
